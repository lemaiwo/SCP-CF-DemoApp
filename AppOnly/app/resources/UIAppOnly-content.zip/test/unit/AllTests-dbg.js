sap.ui.define([
	"be/wl/UIAppOnly/test/unit/controller/app.controller"
], function () {
	"use strict";
});
