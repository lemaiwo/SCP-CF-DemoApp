sap.ui.define([
	"be/wl/DemoApp/test/unit/controller/App.controller"
], function () {
	"use strict";
});
